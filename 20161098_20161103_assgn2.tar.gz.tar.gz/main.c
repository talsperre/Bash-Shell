#include "header.h"

/*
	The main function of the program
*/

int main() {
	initialize();
	loop();
	return 0;
}